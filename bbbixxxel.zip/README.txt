New to variable fonts?

This Article is kinda complex but should answer every question, especially on a technical level: 
https://medium.com/variable-fonts/https-medium-com-tiro-introducing-opentype-variable-fonts-12ba6cd2369

Also check out this tutorial on variable fonts on the web by Dinamo:
https://abcdinamo.com/news/using-variable-fonts-on-the-web

Have fun <3

------------

www.lobbby24.com